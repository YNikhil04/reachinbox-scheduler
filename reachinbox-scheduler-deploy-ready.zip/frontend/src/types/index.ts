export interface EmailRecord {
  id: string;
  recipient: string;
  subject: string;
  status: "pending" | "scheduled" | "sent" | "failed";
  scheduledAt: string | null;
  sentAt: string | null;
  errorMessage: string | null;
}

export interface EmailListResponse {
  data: EmailRecord[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

export interface CreateCampaignPayload {
  subject: string;
  body: string;
  recipients: string[];
  startTime: string;
  delayMs: number;
  hourlyLimit: number;
}
