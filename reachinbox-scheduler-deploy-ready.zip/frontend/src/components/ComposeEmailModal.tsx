"use client";

import { useState } from "react";
import Papa from "papaparse";
import toast from "react-hot-toast";
import Modal from "@/components/ui/Modal";
import Input from "@/components/ui/Input";
import Button from "@/components/ui/Button";
import { api } from "@/lib/api";

interface ComposeEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScheduled: () => void; // callback to refresh the Scheduled table
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function ComposeEmailModal({
  isOpen,
  onClose,
  onScheduled,
}: ComposeEmailModalProps) {
  const [senderEmail, setSenderEmail] = useState(""); // "From"
  const [manualRecipient, setManualRecipient] = useState(""); // "To" quick-add
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [recipients, setRecipients] = useState<string[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [startTime, setStartTime] = useState("");
  const [delaySeconds, setDelaySeconds] = useState(2);
  const [hourlyLimit, setHourlyLimit] = useState(200);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  function resetForm() {
    setSenderEmail("");
    setManualRecipient("");
    setSubject("");
    setBody("");
    setRecipients([]);
    setFileName(null);
    setStartTime("");
    setDelaySeconds(2);
    setHourlyLimit(200);
    setErrors({});
  }

  function addRecipient(email: string) {
    const candidate = email.trim().toLowerCase();
    if (!candidate) return;
    if (!EMAIL_REGEX.test(candidate)) {
      toast.error(`"${candidate}" isn't a valid email address.`);
      return;
    }
    setRecipients((prev) =>
      prev.includes(candidate) ? prev : [...prev, candidate],
    );
  }

  function handleManualAdd() {
    addRecipient(manualRecipient);
    setManualRecipient("");
  }

  function removeRecipient(email: string) {
    setRecipients((prev) => prev.filter((r) => r !== email));
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);

    Papa.parse(file, {
      complete: (results) => {
        const found = new Set<string>();
        for (const row of results.data as string[][]) {
          for (const cell of row) {
            const candidate = cell?.trim();
            if (candidate && EMAIL_REGEX.test(candidate)) {
              found.add(candidate.toLowerCase());
            }
          }
        }
        // Merge with anything already added manually, instead of overwriting.
        setRecipients((prev) => Array.from(new Set([...prev, ...found])));
        if (found.size === 0) {
          toast.error("No valid email addresses found in the file.");
        }
      },
      error: () => toast.error("Failed to parse the file."),
    });
  }

  function validate(): boolean {
    const newErrors: Record<string, string> = {};
    if (senderEmail && !EMAIL_REGEX.test(senderEmail.trim()))
      newErrors.senderEmail = "Enter a valid sender email, or leave blank";
    if (!subject.trim()) newErrors.subject = "Subject is required";
    if (!body.trim()) newErrors.body = "Body is required";
    if (recipients.length === 0)
      newErrors.recipients =
        "Add at least one recipient — type an email or upload a CSV";
    if (!startTime) newErrors.startTime = "Start time is required";
    if (delaySeconds <= 0) newErrors.delaySeconds = "Delay must be positive";
    if (hourlyLimit <= 0)
      newErrors.hourlyLimit = "Hourly limit must be positive";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  async function handleSubmit() {
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      await api.post("/api/campaigns", {
        subject,
        body,
        recipients,
        startTime: new Date(startTime).toISOString(),
        delayMs: delaySeconds * 1000,
        hourlyLimit,
        ...(senderEmail.trim() ? { senderEmail: senderEmail.trim() } : {}),
      });

      toast.success(`Scheduled ${recipients.length} email(s) successfully.`);
      resetForm();
      onScheduled();
      onClose();
    } catch (err: any) {
      toast.error(
        err?.response?.data?.error?.formErrors?.[0] ||
          "Failed to schedule emails.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Compose New Email">
      <div className="space-y-4">
        <Input
          label="From (Sender Email)"
          type="email"
          value={senderEmail}
          onChange={(e) => setSenderEmail(e.target.value)}
          error={errors.senderEmail}
          placeholder="you@yourcompany.com (optional — defaults to your account)"
        />

        <Input
          label="Subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          error={errors.subject}
          placeholder="Your email subject"
        />

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Body
          </label>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={4}
            className={`w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
              errors.body ? "border-red-400" : "border-gray-300"
            }`}
            placeholder="Write your email content..."
          />
          {errors.body && (
            <p className="mt-1 text-xs text-red-600">{errors.body}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            To (Recipients)
          </label>

          <div className="flex gap-2">
            <input
              type="email"
              value={manualRecipient}
              onChange={(e) => setManualRecipient(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  handleManualAdd();
                }
              }}
              placeholder="Type an email and press Enter"
              className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Button type="button" variant="secondary" onClick={handleManualAdd}>
              Add
            </Button>
          </div>

          {recipients.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {recipients.map((r) => (
                <span
                  key={r}
                  className="inline-flex items-center gap-1 rounded-full bg-blue-50 text-blue-700 text-xs pl-2.5 pr-1.5 py-1"
                >
                  {r}
                  <button
                    type="button"
                    onClick={() => removeRecipient(r)}
                    className="text-blue-400 hover:text-blue-700 leading-none"
                    aria-label={`Remove ${r}`}
                  >
                    &times;
                  </button>
                </span>
              ))}
            </div>
          )}

          <div className="mt-2">
            <label className="block text-xs font-medium text-gray-500 mb-1">
              or upload a CSV/TXT of recipients
            </label>
            <input
              type="file"
              accept=".csv,.txt"
              onChange={handleFileUpload}
              className="block w-full text-sm text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-gray-100 file:px-3 file:py-2 file:text-sm file:font-medium hover:file:bg-gray-200"
            />
            {fileName && (
              <p className="mt-1 text-xs text-gray-500">
                {fileName} loaded —{" "}
                <span className="font-medium text-gray-700">
                  {recipients.length} total recipient(s)
                </span>
              </p>
            )}
          </div>

          {errors.recipients && (
            <p className="mt-1 text-xs text-red-600">{errors.recipients}</p>
          )}
        </div>

        <Input
          label="Start Time"
          type="datetime-local"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
          error={errors.startTime}
        />

        <div className="grid grid-cols-2 gap-4">
          <Input
            label="Delay Between Emails (seconds)"
            type="number"
            min={1}
            value={delaySeconds}
            onChange={(e) => setDelaySeconds(Number(e.target.value))}
            error={errors.delaySeconds}
          />
          <Input
            label="Hourly Limit"
            type="number"
            min={1}
            value={hourlyLimit}
            onChange={(e) => setHourlyLimit(Number(e.target.value))}
            error={errors.hourlyLimit}
          />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? "Scheduling..." : "Schedule"}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
