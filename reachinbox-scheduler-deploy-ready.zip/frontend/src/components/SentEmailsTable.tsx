"use client";

import Table from "@/components/ui/Table";
import StatusBadge from "@/components/ui/StatusBadge";
import { useEmails } from "@/hooks/useEmails";
import { EmailRecord } from "@/types";

function formatDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString();
}

export default function SentEmailsTable() {
  // "sent,failed" — the brief requires this tab to show status sent/failed,
  // so we fetch both rather than only successful sends.
  const { emails, isLoading } = useEmails("sent,failed");

  return (
    <Table<EmailRecord>
      isLoading={isLoading}
      emptyMessage="No emails sent yet."
      data={emails}
      columns={[
        { header: "Email", accessor: (row) => row.recipient },
        { header: "Subject", accessor: (row) => row.subject },
        { header: "Sent Time", accessor: (row) => formatDate(row.sentAt) },
        {
          header: "Status",
          accessor: (row) => <StatusBadge status={row.status} />,
        },
      ]}
    />
  );
}
