"use client";

import Table from "@/components/ui/Table";
import StatusBadge from "@/components/ui/StatusBadge";
import { useEmails } from "@/hooks/useEmails";
import { EmailRecord } from "@/types";

function formatDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString();
}

export default function ScheduledEmailsTable() {
  const { emails, isLoading } = useEmails("scheduled");

  return (
    <Table<EmailRecord>
      isLoading={isLoading}
      emptyMessage="No scheduled emails yet — click Compose New Email to create one."
      data={emails}
      columns={[
        { header: "Email", accessor: (row) => row.recipient },
        { header: "Subject", accessor: (row) => row.subject },
        {
          header: "Scheduled Time",
          accessor: (row) => formatDate(row.scheduledAt),
        },
        {
          header: "Status",
          accessor: (row) => <StatusBadge status={row.status} />,
        },
      ]}
    />
  );
}
