"use client";

import Image from "next/image";

interface HeaderProps {
  name: string;
  email: string;
  avatarUrl?: string | null;
}

export default function Header({ name, email, avatarUrl }: HeaderProps) {
  return (
    <header className="flex items-center justify-between border-b border-gray-200 bg-white px-6 py-4">
      <h1 className="text-lg font-semibold text-gray-900">
        ReachInbox Scheduler
      </h1>

      <div className="flex items-center gap-3">
        <div className="text-right">
          <p className="text-sm font-medium text-gray-900">{name}</p>
          <p className="text-xs text-gray-500">{email}</p>
        </div>
        {avatarUrl ? (
          <Image
            src={avatarUrl}
            alt={name}
            width={36}
            height={36}
            className="rounded-full"
          />
        ) : (
          <div className="h-9 w-9 rounded-full bg-gray-200" />
        )}
        <button
          onClick={() => {
            window.location.href = `${process.env.NEXT_PUBLIC_API_URL}/auth/logout`;
          }}
          className="ml-2 text-sm text-gray-500 hover:text-red-600 transition"
        >
          Logout
        </button>
      </div>
    </header>
  );
}
