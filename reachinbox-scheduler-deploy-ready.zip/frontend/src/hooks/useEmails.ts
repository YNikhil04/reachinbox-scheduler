"use client";

import { useEffect, useState, useCallback } from "react";
import { api } from "@/lib/api";
import { EmailRecord } from "@/types";

// Accepts either a single status ("scheduled") or a comma-separated
// list ("sent,failed") — the backend supports both via the same
// `status` query param.
export function useEmails(status: string) {
  const [emails, setEmails] = useState<EmailRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchEmails = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.get(
        `/api/emails?status=${encodeURIComponent(status)}`,
      );
      setEmails(res.data.data);
    } catch (err) {
      setError("Failed to load emails");
    } finally {
      setIsLoading(false);
    }
  }, [status]);

  useEffect(() => {
    fetchEmails();
  }, [fetchEmails]);

  return { emails, isLoading, error, refetch: fetchEmails };
}
