import { redirect } from "next/navigation";

// Auth is handled client-side (see hooks/useAuth.ts and app/dashboard/page.tsx),
// so this just sends everyone to the dashboard — it will bounce
// unauthenticated users to /login itself.
export default function Home() {
  redirect("/dashboard");
}
