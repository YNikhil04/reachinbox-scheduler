"use client";

import { useState } from "react";
import Header from "@/components/layout/Header";
import Tabs from "@/components/ui/Tabs";
import Button from "@/components/ui/Button";
import ScheduledEmailsTable from "@/components/ScheduledEmailsTable";
import SentEmailsTable from "@/components/SentEmailsTable";
import ComposeEmailModal from "@/components/ComposeEmailModal";

interface DashboardClientProps {
  name: string;
  email: string;
  avatarUrl?: string | null;
}

export default function DashboardClient({
  name,
  email,
  avatarUrl,
}: DashboardClientProps) {
  const [activeTab, setActiveTab] = useState("scheduled");
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  function handleScheduled() {
    setActiveTab("scheduled");
    setRefreshKey((k) => k + 1); // forces the table to remount and refetch
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header name={name} email={email} avatarUrl={avatarUrl} />

      <main className="mx-auto max-w-5xl px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <Tabs
            tabs={[
              { key: "scheduled", label: "Scheduled Emails" },
              { key: "sent", label: "Sent Emails" },
            ]}
            activeTab={activeTab}
            onChange={setActiveTab}
          />
          <Button onClick={() => setIsComposeOpen(true)}>
            + Compose New Email
          </Button>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-sm">
          {activeTab === "scheduled" && (
            <ScheduledEmailsTable key={`scheduled-${refreshKey}`} />
          )}
          {activeTab === "sent" && (
            <SentEmailsTable key={`sent-${refreshKey}`} />
          )}
        </div>
      </main>

      <ComposeEmailModal
        isOpen={isComposeOpen}
        onClose={() => setIsComposeOpen(false)}
        onScheduled={handleScheduled}
      />
    </div>
  );
}
