export default function LoginPage() {
  const backendUrl = process.env.NEXT_PUBLIC_API_URL;

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="w-full max-w-sm rounded-xl bg-white p-8 shadow-md text-center">
        <h1 className="text-2xl font-semibold mb-2">ReachInbox Scheduler</h1>
        <p className="text-gray-500 mb-6">
          Sign in to manage your email campaigns
        </p>
        <a
          href={`${backendUrl}/auth/google`}
          className="block w-full rounded-lg bg-blue-600 text-white py-2
        font-medium hover:bg-blue-700 transition"
        >
          Continue with Google
        </a>
      </div>
    </div>
  );
}
