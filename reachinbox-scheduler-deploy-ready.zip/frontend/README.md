# Frontend — ReachInbox Scheduler

Next.js (App Router) + TypeScript + Tailwind CSS dashboard for the ReachInbox Scheduler assignment.

See the root [README.md](../README.md) for full setup instructions and architecture notes.

## Quick start

```bash
npm install
cp .env.local.example .env.local   # set NEXT_PUBLIC_API_URL if your backend isn't on localhost:5000
npm run dev
```

Requires the backend (see `../backend/README.md`) to be running for login and data to work.
