# Backend — ReachInbox Scheduler

Express + TypeScript API, BullMQ worker, and PostgreSQL (via Prisma) for the ReachInbox Scheduler assignment.

See the root [README.md](../README.md) for full setup instructions and architecture notes.

## Quick start

```bash
npm install
cp .env.example .env   # fill in real Google OAuth + Ethereal credentials
npx prisma migrate dev
npm run dev      # API server
npm run worker   # BullMQ worker — run in a separate terminal, this is what actually sends emails
```

## Key scripts

| Script | What it does |
|---|---|
| `npm run dev` | Starts the Express API with hot reload |
| `npm run worker` | Starts the BullMQ worker process (separate from the API on purpose — mirrors how you'd scale workers independently in production) |
| `npm run build` | Compiles TypeScript to `dist/` |
| `npm run start` | Runs the compiled build |
