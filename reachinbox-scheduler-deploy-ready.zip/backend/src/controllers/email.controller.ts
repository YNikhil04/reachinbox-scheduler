import { Request, Response } from "express";
import prisma from "../config/db";

const VALID_STATUSES = ["pending", "scheduled", "sent", "failed"] as const;

// Explicit shape of a row returned by the query below (Email + its
// campaign's subject). Declared by hand rather than relied on being
// inferred, so this stays stable regardless of how a given environment's
// generated Prisma client types resolve.
interface EmailRow {
  id: string;
  recipient: string;
  status: string;
  scheduledAt: Date | null;
  sentAt: Date | null;
  errorMessage: string | null;
  campaign: { subject: string };
}

export async function listEmails(req: Request, res: Response) {
  const user = req.user as { id: string };
  if (!user?.id) {
    return res.status(401).json({ error: "Not authenticated" });
  }

  // Supports a single status ("sent") or a comma-separated list
  // ("sent,failed") so the frontend's "Sent Emails" tab can show
  // both sent and failed rows in one request, as required by the brief.
  const statusParam = req.query.status as string | undefined;
  const statuses = statusParam
    ? statusParam.split(",").map((s) => s.trim())
    : undefined;

  const page = Math.max(Number(req.query.page) || 1, 1);
  const pageSize = Math.min(Number(req.query.pageSize) || 20, 100);

  if (statuses) {
    const invalid = statuses.filter(
      (s) => !VALID_STATUSES.includes(s as any),
    );
    if (invalid.length > 0) {
      return res.status(400).json({
        error: `Invalid status: ${invalid.join(", ")}. Must be one of: ${VALID_STATUSES.join(", ")}`,
      });
    }
  }

  const where = statuses
    ? { campaign: { userId: user.id }, status: { in: statuses } }
    : { campaign: { userId: user.id } };

  const [emails, total] = await Promise.all([
    prisma.email.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        campaign: { select: { subject: true } },
      },
    }),
    prisma.email.count({ where }),
  ]);

  const shaped = (emails as EmailRow[]).map((e) => ({
    id: e.id,
    recipient: e.recipient,
    subject: e.campaign.subject,
    status: e.status,
    scheduledAt: e.scheduledAt,
    sentAt: e.sentAt,
    errorMessage: e.errorMessage,
  }));

  res.json({
    data: shaped,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    },
  });
}
