import express from "express";
import cors from "cors";
import session from "express-session";
import dotenv from "dotenv";
import passport from "./config/passport";
import authRoutes from "./routes/auth.routes";
import meRoutes from "./routes/me.routes";
import uploadRoutes from "./routes/upload.routes";
import campaignRoutes from "./routes/campaign.routes";
import emailRoutes from "./routes/email.routes";

dotenv.config();

const app = express();
const isProduction = process.env.NODE_ENV === "production";
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

// Render (and most PaaS hosts) sit behind a reverse proxy that terminates
// TLS. Without this, Express thinks every request is plain HTTP, and a
// `secure: true` session cookie below would never actually get set.
if (isProduction) {
  app.set("trust proxy", 1);
}

app.use(
  cors({
    origin: FRONTEND_URL,
    credentials: true, // required so cookies/session travel with requests
  }),
);
app.use(express.json());

app.use(
  session({
    secret: process.env.SESSION_SECRET || "fallback-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      // Frontend (Vercel) and backend (Render) live on different domains
      // in production, so the session cookie must be marked SameSite=None
      // (cross-site) and Secure (HTTPS-only) or the browser will silently
      // refuse to send it back on API calls.
      secure: isProduction,
      sameSite: isProduction ? "none" : "lax",
    },
  }),
);
app.use(passport.initialize());
app.use(passport.session());

app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.use("/auth", authRoutes);
app.use("/api", meRoutes);

app.use("/api", uploadRoutes);
app.use("/api", campaignRoutes);

app.use("/api", emailRoutes);

export default app;
