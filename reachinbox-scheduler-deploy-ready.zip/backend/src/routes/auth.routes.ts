import { Router } from "express";
import passport from "../config/passport";

const router = Router();
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

router.get(
  "/google",
  passport.authenticate("google", { scope: ["profile", "email"] }),
);

router.get(
  "/google/callback",
  passport.authenticate("google", {
    failureRedirect: `${FRONTEND_URL}/login`,
    session: true,
  }),
  (req, res) => {
    // successful login — redirect to frontend dashboard
    res.redirect(`${FRONTEND_URL}/dashboard`);
  },
);

router.get("/logout", (req, res) => {
  req.logout(() => {
    res.redirect(`${FRONTEND_URL}/login`);
  });
});

export default router;
