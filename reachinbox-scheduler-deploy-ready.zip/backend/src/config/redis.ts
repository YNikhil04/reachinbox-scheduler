import IORedis from "ioredis";
import dotenv from "dotenv";
dotenv.config();

// Render's managed Redis (and most hosted Redis providers) give you a
// single connection string like rediss://user:pass@host:port instead of
// separate host/port — support both so the same code works locally
// (via Docker Compose) and in production.
const connection = process.env.REDIS_URL
  ? new IORedis(process.env.REDIS_URL, {
      maxRetriesPerRequest: null, // required by BullMQ
    })
  : new IORedis({
      host: process.env.REDIS_HOST || "localhost",
      port: Number(process.env.REDIS_PORT) || 6379,
      password: process.env.REDIS_PASSWORD || undefined,
      maxRetriesPerRequest: null, // required by BullMQ
    });

connection.on("connect", () => console.log("✅ Redis connected"));
connection.on("error", (err) => console.error("❌ Redis error:", err));

export default connection;
